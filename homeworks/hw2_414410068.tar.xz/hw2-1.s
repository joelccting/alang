/*	Q2-1	*/
	.section .text
	.global main
	.type main, %function
main:
	ldr	r1,=#0x1122		@ r1 := 0x1122 
	ldr 	r2,=#0x3344		@ r2 := 0x3344
	ldr	r3,=#0x5566		@ r3 := 0x5566 
	add	r1, r1, r2		@ r1 := r1 + r2 
	add	r1, r1, r2, lsl #3	@ r1 := r1 + r2 * 8
	sub	r1, r1, r3, lsl #4	@ r1 := r1 - r3 * 16
	mov	r0, r1			@ r0 := r1
	nop
	.end
