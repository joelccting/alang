Homework #2 
414410068 丁家駿

README.txt: 這個檔案 

hw2-1.s、hw2-2.s: Your ARM assembly program

hw2-1.exe、hw2-2.exe: 編譯好的執行檔

如何編譯程式: 
	$ arm-none-eabi-gcc -g -O0 hw2-1.s -o hw2-1.exe
	$ arm-none-eabi-gcc -g -O0 hw2-2.s -o hw2-2.exe

程式的執行環境:
	Windows 11: 一、運行的 Virtualbox 7.2 版；二、執行 XLaunch 跑 X Window Server
	虛擬機運行 Ubuntu 22.04 LTS Live Server 版
	
如何執行程式:
	執行以下指令觀察 hw2-1.s
	$ arm-none-eabi-insight hw2-1.exe & 
	
	執行以下指令觀察 hw2-2.s
	$ arm-none-eabi-insight hw2-2.exe &
	


