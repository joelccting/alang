/*	Q2-2	*/
	.section .text
	.global main
	.type main, %function
main:
	ldr	r1, =#0x87654321	@ r1 := 0x87654321
	ldr	r2, =#0x000000FF	@ r2 := 0x000000FF
	mov	r0, r1, lsr #2		@ r0 := (r1 >> 2)
	and	r0, r0, r2		@ r0 := r0 & r2	
	nop
	.end
