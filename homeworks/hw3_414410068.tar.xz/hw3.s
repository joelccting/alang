/* ========================= */
/*       DATA section        */
/* ========================= */

/*
 *          [ 3 4 5 6 ]
 * [ 2 3 4 ][ 4 5 6 7 ] = [0x26 0x2f 0x38 0x41]
 *          [ 5 6 7 8 ]
 */
	.data
	.align 4

/* --- Matrix A --- */
	.type A, %object
	.size A, 12
A:
	.word 2 /* A(1, 1) */
	.word 3 /* A(1, 2) */
	.word 4 /* A(1, 3) */

/* --- Matrix B --- */
	.type B, %object
	.size B, 48
B:
	.word 3	/* B(1, 1) */
	.word 4	/* B(1, 2) */
	.word 5	/* B(1, 3) */
	.word 6	/* B(1, 4) */

	.word 4	/* B(2, 1) */
	.word 5	/* B(2, 2) */
	.word 6	/* B(2, 3) */
	.word 7 /* B(2, 4) */

	.word 5	/* B(3, 1) */
	.word 6	/* B(3, 2) */
	.word 7 /* B(3, 3) */
	.word 8 /* B(3, 4) */

/* --- Matrix C --- */
C:
	.space 16, 0 /* C(1,1) */
                     /* C(1,2) */
	             /* C(1,3) */
                     /* C(1,4) */

/* ========================= */
/*       TEXT section        */
/* ========================= */
	.section .text
	.global main
	.type main,%function
.matrix:
	.word A
	.word B
	.word C
main:
	ldr r0, =A

	/* Load matrix A */
	ldm r0, {r1, r2, r3} /* r1 := mem32[r0] */
                             /* r2 := mem32[r0 + 4] */
                             /* r3 := mem32[r0 + 8] */

	ldr r0, =B           /* r0 := B */ 
	bl vec_mul           /* call function vec_mul */
	ldr r7, =C           /* r7 := C */
	str r0, [r7]         /* mem32[r7] = r0  */

	ldr r0, =B + 4       /* r0 := B + 4 */
	bl vec_mul           /* call function vec_mul */
	ldr r7, =C + 4       /* r7 := C + 4 */
	str r0, [r7]         /* mem32[r7] = r0 */

	ldr r0, =B + 8       /* r0 := B + 8 */
	bl vec_mul           /* call function vec_mul */
	ldr r7, =C + 8       /* r7 := C + 8 */
	str r0, [r7]         /* mem32[r7] = r0 */

	ldr r0, =B + 12      /* r0 := B + 12 */
	bl vec_mul           /* call function vec_mul */
	ldr r7, =C + 12      /* r7 := C + 12 */
	str r0, [r7]         /* mem32[r7] = r0 */

	ldr r0, =C           /* r0 := C */
	b exit               /* go to exit */

vec_mul:
	/* Load a column of matrix B */
	ldr r4, [r0], #16 /* r4 := mem32[r0] */
                          /* r0 := r0 + 16   */
	ldr r5, [r0], #16 /* r5 := mem32[r0] */
                          /* r0 := r0 + 16   */
        ldr r6, [r0]      /* r6 := mem32[r0] */

	mul r4, r1, r4    /* r4 := r1 * r4   */
	mul r5, r2, r5    /* r5 := r2 * r5   */
	mul r6, r3, r6    /* r6 := r3 * r6   */
	add r0, r4, r5    /* r0 := r4 + r5   */
	add r0, r0, r6    /* r0 := r0 + r6   */
	mov pc, lr 

exit:
        nop
	.end
