Homework #3
414410068 丁家駿

README.txt: 這個檔案 

hw3.s: My ARM assembly program

hw3.exe: 編譯好的執行檔

如何編譯程式: 
	$ make clean; make

程式的執行環境:
	一、Windows 11 執行 Virtualbox 7.2 版開啟 Ubuntu 22.04 LTS Live Server 版，進入 bash；
	二、startx 執行 openbox 跑簡易桌面；
	三、執行 arm-none-eabi-insight
	
如何執行程式:
	執行以下指令觀察 hw3.s
	$ arm-none-eabi-insight hw3.exe & 
	
預期結果：
	計算
               [3 4 5 6]
        [2 3 4][4 5 6 7] = [38 47 56 65] = [0x26 0x2f 0x38 0x41]
		       [5 6 7 8]
	
	1x3 矩陣 A [2 3 4] 放在 r1, r2, r3
	3x4 矩陣 B 共四個 column vector 分四次放在 r4, r5, r6
    每計算一次，就把結果依次存儲在以 1x4 矩陣 C 為起始地址的陣列當中	

